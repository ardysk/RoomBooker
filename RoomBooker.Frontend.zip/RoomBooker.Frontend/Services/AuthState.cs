﻿using System;
using System.Threading.Tasks;

namespace RoomBooker.Frontend.Services;

public class AuthState
{
    private readonly ApiClient _apiClient;

    public string? UserEmail { get; private set; }
    public bool IsAuthenticated => !string.IsNullOrEmpty(UserEmail);

    public event Action? OnChange;

    public AuthState(ApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    public async Task<bool> LoginAsync(string email, string password)
    {
        var ok = await _apiClient.LoginAsync(email, password);
        if (ok)
        {
            UserEmail = email;
            NotifyStateChanged();
        }

        return ok;
    }

    public async Task LogoutAsync()
    {
        await _apiClient.LogoutAsync(); // w środku tylko czyścimy token
        UserEmail = null;
        NotifyStateChanged();
    }

    private void NotifyStateChanged() => OnChange?.Invoke();
}
