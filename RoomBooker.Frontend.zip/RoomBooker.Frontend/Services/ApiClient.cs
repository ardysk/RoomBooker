﻿using RoomBooker.Core.Dtos;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace RoomBooker.Frontend.Services;

public class ApiClient
{
    private readonly HttpClient _http;

    // przechowujemy token JWT, żeby móc go wyczyścić przy logout
    private string? _jwtToken;
    public string? JwtToken => _jwtToken;
    public bool IsAuthenticated => !string.IsNullOrEmpty(_jwtToken);

    public ApiClient(HttpClient http)
    {
        _http = http;
    }

    // --- Auth -------------------------------------------------------------

    public async Task<bool> LoginAsync(string email, string password)
    {
        var payload = new LoginRequestDto
        {
            Email = email,
            Password = password
        };

        var response = await _http.PostAsJsonAsync("/api/Auth/login", payload);
        if (!response.IsSuccessStatusCode)
            return false;

        // API zwraca token jako string w JSON, więc odczytujemy go tak jak wcześniej
        var raw = await response.Content.ReadAsStringAsync();
        var token = raw.Trim('"');

        if (string.IsNullOrWhiteSpace(token))
            return false;

        _jwtToken = token;
        _http.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", _jwtToken);

        return true;
    }

    public Task LogoutAsync()
    {
        _jwtToken = null;
        _http.DefaultRequestHeaders.Authorization = null;
        return Task.CompletedTask;
    }

    public async Task<bool> RegisterAsync(RegisterUserDto dto)
    {
        // Uwaga na wielkość liter w ścieżce: AuthController -> /api/Auth/...
        var response = await _http.PostAsJsonAsync("/api/Auth/register", dto);
        return response.IsSuccessStatusCode;
    }

    // --- Rooms ------------------------------------------------------------

    public async Task<List<RoomDto>> GetRoomsAsync()
        => await _http.GetFromJsonAsync<List<RoomDto>>("/api/Rooms") ?? new();

    public async Task<RoomDto> CreateRoomAsync(RoomDto room)
    {
        var response = await _http.PostAsJsonAsync("/api/Rooms", room);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<RoomDto>())!;
    }

    public async Task<RoomDto?> UpdateRoomAsync(int id, RoomDto room)
    {
        var response = await _http.PutAsJsonAsync($"/api/Rooms/{id}", room);
        if (!response.IsSuccessStatusCode)
            return null;

        return await response.Content.ReadFromJsonAsync<RoomDto>();
    }

    public async Task DeactivateRoomAsync(int id)
    {
        var response = await _http.PostAsync($"/api/Rooms/{id}/deactivate", null);
        response.EnsureSuccessStatusCode();
    }

    // --- Reservations -----------------------------------------------------

    public async Task<List<ReservationDto>> GetReservationsForRoomAsync(int roomId)
        => await _http.GetFromJsonAsync<List<ReservationDto>>($"/api/Reservations/room/{roomId}") ?? new();

    public async Task<ReservationDto> CreateReservationAsync(ReservationCreateDto dto)
    {
        var response = await _http.PostAsJsonAsync("/api/Reservations", dto);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<ReservationDto>())!;
    }

    public async Task ApproveReservationAsync(int id)
        => (await _http.PostAsync($"/api/Reservations/{id}/approve", null))
            .EnsureSuccessStatusCode();

    public async Task RejectReservationAsync(int id)
        => (await _http.PostAsync($"/api/Reservations/{id}/reject", null))
            .EnsureSuccessStatusCode();

    public async Task CancelReservationAsync(int id)
        => (await _http.PostAsync($"/api/Reservations/{id}/cancel", null))
            .EnsureSuccessStatusCode();
}
