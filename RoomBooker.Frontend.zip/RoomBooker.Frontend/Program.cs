using RoomBooker.Frontend.Components;
using RoomBooker.Frontend.Services;

var builder = WebApplication.CreateBuilder(args);

// Razor Components (Blazor na .NET 8)
builder.Services
    .AddRazorComponents()
    .AddInteractiveServerComponents();

// HttpClient do API backendu
builder.Services.AddHttpClient<ApiClient>(client =>
{
    // ADRES BACKENDU � je�li inny, wpisz sw�j
    client.BaseAddress = new Uri(
        builder.Configuration["ApiBaseUrl"]
        ?? "https://localhost:7164"   // albo np. "http://localhost:5100"
    );
});

// stan autoryzacji
builder.Services.AddScoped<AuthState>();
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// Tu jest g��wny komponent aplikacji � App.razor
app.MapRazorComponents<App>()
   .AddInteractiveServerRenderMode();

app.Run();
